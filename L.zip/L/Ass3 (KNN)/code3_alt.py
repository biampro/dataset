import pandas as pd
from sklearn.neighbors import KNeighborsClassifier

dataset = pd.read_csv('dataset.csv')
X = dataset.iloc[:,[0, 1]].values    #IV
Y = dataset.iloc[:,2].values   #DV

classifier = KNeighborsClassifier(n_neighbors=3)
classifier.fit(X, Y)

X_pred = [(6, 6)]
Y_pred = classifier.predict(X_pred)

#Results
print("------------------------")
print(Y_pred)
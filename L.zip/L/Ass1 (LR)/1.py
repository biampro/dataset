import pandas as pd

data_set = pd.read_csv("dataset.csv")
X=data_set.iloc[:,[0]].values    #IV # first column of data frame (first_name)
Y=data_set.iloc[:,[1]].values   #DV # second column of data frame (last_name)

#fitting Classifier to te Training set
from sklearn.linear_model import LinearRegression
linearRegressor = LinearRegression()
linearRegressor.fit(X,Y)
#predicting the test set result
linearRegressor.score(X,Y)

#Results
import matplotlib.pyplot as plot
plot.scatter(X, Y, color = 'red')
plot.plot(X, linearRegressor.predict(X), color = 'blue')
plot.title('Title')
plot.xlabel('Number of hours spent driving')
plot.ylabel('Risk score on a scale of 0-100')
plot.show()



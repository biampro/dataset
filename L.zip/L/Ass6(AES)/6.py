from Crypto.Cipher import AES

key = "This is a key123"
message = "Hello from the other sideeeeeeee"

aes = AES.new(key)
cipher = aes.encrypt(message)

decipher = aes.decrypt(cipher)

print("Plain Text: " + str(message))
print("Cipher Text: " + str(cipher))
print("Decrypted Text: " + str(decipher))
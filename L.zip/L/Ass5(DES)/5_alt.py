from Crypto.Cipher import DES

key = "81491365"
message = "Hello from the 1"

des = DES.new(key)
cipher = des.encrypt(message)
decipher = des.decrypt(cipher)

print("Plain Text:" + str(message))
print("Cipher Text: " + str(cipher))
print('Decrypted Text: ' + str(decipher))
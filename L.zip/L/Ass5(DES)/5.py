def permute_p10(text):
    p10 = [2, 4, 1, 6, 3, 9, 0, 8, 7, 6]
    temp = [0 for i in range(10)]
    for i in range(len(text)):
        temp[i] = text[p10[i]]
    return "".join(temp)


def permute_p8(text):
    p8 = [5, 2, 6, 3, 7, 4, 9, 8]
    temp = [0 for i in range(len(text) - 2)]
    for i in range(8):
        temp[i] = text[p8[i]]
    return "".join(temp)


def permute_initial(text):
    ip = [1, 5, 2, 0, 3, 7, 4, 6]
    temp = [0 for i in range(len(text))]
    for i in range(len(text)):
        temp[i] = text[ip[i]]
    return "".join(temp)


def permute_inverse(text):
    inip = [3, 0, 2, 4, 6, 1, 7, 5]
    temp = [0 for i in range(len(text))]
    for i in range(len(text)):
        temp[i] = text[inip[i]]
    return "".join(temp)


def expand_permute(text):
    ep = [3, 0, 1, 2, 1, 2, 3, 0]
    temp = [0 for i in range(2 * len(text))]
    for i in range(2 * len(text)):
        temp[i] = text[ep[i]]
    return "".join(temp)


def permute_p4(text):
    p4 = [1, 3, 2, 0]
    temp = [0 for i in range(len(text))]
    for i in range(len(text)):
        temp[i] = text[p4[i]]
    return "".join(temp)


def generate_key(key):
    p10 = permute_p10(key)
    left = p10[:len(p10) // 2]
    right = p10[len(p10) // 2:]
    left = left[1:] + left[0]
    right = right[1:] + right[0]
    key1 = permute_p8(left + right)
    left = left[2:] + left[0:2]
    right = right[2:] + right[0:2]
    key2 = permute_p8(left + right)
    return key1, key2


def permute_sbox(left, right):
    s0 = [['01', '00', '11', '10'], ['11', '10', '01', '00'], ['00', '10', '01', '11'], ['11', '01', '11', '10']]
    s1 = [['00', '01', '10', '11'], ['10', '00', '01', '11'], ['11', '00', '01', '00'], ['10', '01', '00', '11']]
    row1 = int(left[0] + left[3], 2)
    col1 = int(left[1:3], 2)
    row2 = int(right[0] + right[3], 2)
    col2 = int(right[1:3], 2)
    return s0[row1][col1] + s1[row2][col2]


def xor(bit, a, b):
    temp = int(a, 2) ^ int(b, 2)
    temp = bin(temp)
    temp = temp[2:]
    k = bit - len(temp)
    temp = "0" * k + temp
    return temp


def encrypt(text, key1, key2):
    ip = permute_initial(text)
    left = ip[:len(ip) // 2]
    right = ip[len(ip) // 2:]
    ep = expand_permute(right)
    temp = xor(8, ep, key1)
    sbox = permute_sbox(temp[:len(temp) // 2], temp[len(temp) // 2:])
    p4 = permute_p4(sbox)
    temp = xor(4, p4, left)
    temp = right + temp
    left = temp[:len(temp) // 2]
    right = temp[len(temp) // 2:]
    ep = expand_permute(right)
    temp = xor(8, ep, key2)
    sbox = permute_sbox(temp[:len(temp) // 2], temp[len(temp) // 2:])
    p4 = permute_p4(sbox)
    temp = xor(4, p4, left)
    temp = temp + right
    return permute_inverse(temp)


def decrypt(text, key1, key2):
    ip = permute_initial(text)
    left = ip[:len(ip) // 2]
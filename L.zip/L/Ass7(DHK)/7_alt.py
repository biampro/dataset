p=int(input("ENter first number "))
q=int(input("Enter second number "))
#secret number selected by alice
a=int(input("Enter secret number a "))
r=pow(q,a)%p
#secret number selected by bob
b=int(input("Enter secret number b "))
s=pow(q,b)%p
print("Exchanging keys.....")
rk=pow(s,a)%p
print("Secret key calculated by alice is: ",rk)
sk=pow(r,b)%p
print("Secret key calculated by alice is: ",sk)
if(rk==sk):
   print("alice and bob can agree for further communication")
else:
  print("Something went wrong")

"""
ENter first number 23
Enter second number 15
Enter secret number a 9
Enter secret number b 7
Exchanging keys.....
Secret key calculated by alice is:  19
Secret key calculated by alice is:  19
alice and bob can agree for further communication
"""
import java.util.*;
import java.math.BigInteger;

public class Ass7
{
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        BigInteger p;
        
        System.out.println("Enter 1st prime no. p: ");
        String ans = sc.next();
        //p=getNextPrime(ans);
        p=new BigInteger(ans);
        System.out.println("Enter 2nd prime no. q: ");
        BigInteger g= new BigInteger(sc.next());
        System.out.println("Alice, select your secret number a:");
        BigInteger a = new BigInteger(sc.next());

        BigInteger resulta= g.modPow(a,p);
        System.out.println("Alice sends x to Bob : "+resulta);

        System.out.println("Bob, select your secret number b:");
        BigInteger b = new BigInteger(sc.next());

        BigInteger resultb= g.modPow(b,p);
        System.out.println("Bob sends y to Alice : "+resultb);

        //calculte secret key of Alice and Bob

        BigInteger keyACalculates = resultb.modPow(a,p);
        BigInteger keyBCalculates = resulta.modPow(b,p);
        
        System.out.println("Alice takes "+resultb+" raise to mod p "+a+"mod"+p);
        System.out.println("The secret key Ka Alice calculates is "+keyACalculates+".");
        System.out.println("Bob takes "+resulta+" raise to mod p "+b+"mod"+p);
        System.out.println("The secret key Kb Bob calculates is "+keyBCalculates+"."); 
        

	
        sc.close();
    }
}
/*
OUTPUT:
*****OUTPUT 1*****
D:\New folder>java DiffieHellman
Enter 1st prime no. p:
17
Enter 2nd prime no. q:
11
Alice, select your secret number a:
5
Alice sends x to Bob : 10
Bob, select your secret number b:
3
Bob sends y to Alice : 5
Alice takes 5 raise to mod p 5mod17
The secret key Ka Alice calculates is 14.
Bob takes 10 raise to mod p 3mod17
The secret key Kb Bob calculates is 14.

*****OUTPUT 2*****
 
Enter 1st prime no. p:
23
Enter 2nd prime no. q:
9
Alice, select your secret number a:
4
Alice sends x to Bob : 6
Bob, select your secret number b:
3
Bob sends y to Alice : 16
Alice takes 16 raise to mod p 4mod23
The secret key Ka Alice calculates is 9.
Bob takes 6 raise to mod p 3mod23
The secret key Kb Bob calculates is 9.


*/

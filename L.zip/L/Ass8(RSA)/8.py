#RSA Algorithm
import math
l = []
p = int(input("Enter the 2 digit number:"))
a = int(input("Enter a prime number A:"))
b = int(input("Enter a prime number B other than A:"))

n = a * b
n1 = (a-1)*(b-1) #phi

for i in range(1, n1 + 1):
    if math.gcd(i, n1) == 1:
        l.append(i)
print(l)

e = int(input("Select encryption key e from the list:"))
for i in range(1, 100):
    if ((e * i) % n1) == 1:
        d = i
        break;
c=(p**e) % n
print("Cipher text to be send to reciever is: {}" .format(c))
t=(c**d)%n
print("Text after decryption is: {}".format(t))

"""
Enter the plain text:(2 digit only):2
Enter a prime number A:7
Enter a prime number B other than A:5
[1, 5, 7, 11, 13, 17, 19, 23]
Select encryption key e from the list:19
Cipher text to be send to reciever is: 23
Text after decryption is: 2
"""
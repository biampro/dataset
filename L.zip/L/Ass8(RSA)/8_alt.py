def encrypt(text, e, n):
    text = list(text)
    for i in range(len(text)):
        text[i] = ord(text[i])
        text[i] = pow(text[i], e) % n
        text[i] = chr(text[i])
    return text


def decrypt(text, d, n):
    text = list(text)
    for i in range(len(text)):
        text[i] = ord(text[i])
        text[i] = pow(text[i], d) % n
        text[i] = chr(text[i])
    return text


def gcd(a, b):
    if (b % a == 0):
        return a
    else:
        return gcd(b % a, a)


if __name__ == "__main__":
    p, q = 13, 11
    n = p * q
    phi = (p - 1) * (q - 1)
    e = 2
    while True:
        if (gcd(e, phi) == 1 and e < phi):
            break
        else:
            e += 1
    d = 0
    for i in range(1, 100):
        d = ((phi * i) + 1) / e
        if ((d - int(d)) == 0):
            break
    d = int(d)
    print(d)
    print("public key is ({},{})".format(e, n))
    print("private key is ({},{})".format(d, n))
    plain = input("Enter message ")
    cipher = encrypt(plain, e, n)
    print("ENcrypted text is ")
    print(cipher)
    plain = decrypt(cipher, d, n)
    print("Decrypted text is")
    print("".join(plain))